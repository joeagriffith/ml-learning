import matplotlib.pyplot as plt
import torch
from tqdm.auto import trange

def showImage(img):
    plt.imshow(img.squeeze().cpu(), cmap='gray')
    plt.axis('off')
    plt.show()

def showImages(imgs):
    fig, axes = plt.subplots(1, len(imgs), figsize=(15,5))
    for i, ax in enumerate(axes):
        ax.imshow(imgs[i].squeeze().cpu(), cmap='gray')
        ax.axis('off')
    plt.show()

def showExamples(imgs):
    plt.figure(figsize=(8,8))
    for i in range(16):
        plt.subplot(4,4,i+1)
        plt.imshow(imgs[i].squeeze().cpu(), cmap='gray')
        plt.axis('off')
    plt.show()